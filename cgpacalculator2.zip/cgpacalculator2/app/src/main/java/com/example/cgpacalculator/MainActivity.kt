package com.example.cgpacalculator

import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var etSubject1: EditText
    private lateinit var spinnerCredit1: Spinner
    private lateinit var btnCalculate: Button
    private lateinit var textViewResult: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize UI components
        etSubject1 = findViewById(R.id.etSubject1)
        spinnerCredit1 = findViewById(R.id.spinnerCredit1)
        btnCalculate = findViewById(R.id.btnCalculate)
        textViewResult = findViewById(R.id.textViewResult)

        // Set up Spinner with credit hours options
        val creditHours = arrayOf(2, 3, 4)
        val spinnerAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, creditHours)
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerCredit1.adapter = spinnerAdapter

        // Set click listener for Calculate button
        btnCalculate.setOnClickListener {
            calculateCGPA()
        }
    }

    private fun calculateCGPA() {
        // Get values from the UI
        val grade1 = etSubject1.text.toString().toDoubleOrNull()
        val credit1 = spinnerCredit1.selectedItem as Int

        if (grade1 != null) {
            // CGPA calculation logic
            val totalGradePoints = grade1 * credit1
            val totalCredits = credit1
            val cgpa = totalGradePoints / totalCredits

            // Display the result
            textViewResult.text = "CGPA: %.2f".format(cgpa)
        } else {
            textViewResult.text = "Please enter a valid grade."
        }
    }
}
